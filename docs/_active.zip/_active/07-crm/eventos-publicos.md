# Eventos Públicos

Este documento descreve o fluxo completo de eventos públicos, desde a criação no CRM até a inscrição pelo usuário final.

## Visão Geral

O sistema de eventos permite:
- **Admins**: Criar, gerenciar e acompanhar eventos
- **Público**: Visualizar eventos disponíveis e se inscrever
- **CRM**: Integração automática de inscrições como leads

## Fluxo do Evento

```
[Admin cria evento] → [Evento publicado] → [Usuário se inscreve] → [CRM recebe lead]
         ↓                    ↓                     ↓                    ↓
    /admin/crm/eventos    /eventos           /eventos/:slug        crm_interactions
```

## Páginas Públicas

### Lista de Eventos (`/eventos`)

Página pública que exibe todos os eventos publicados com:
- Filtros por tipo (workshop, curso, palestra, encontro, encontro de networking, conferência)
- Filtros por formato (online, presencial, híbrido)
- Busca por texto
- Cards com informações resumidas
- Link para página de detalhes

### Detalhes do Evento (`/eventos/:slug`)

Página individual do evento com:
- Imagem de capa
- Data, hora e local
- Descrição completa
- Instrutor/palestrante
- Contagem de vagas
- Formulário de inscrição

## Formulário de Inscrição

### Campos Padrão
- Nome completo (obrigatório)
- Email (obrigatório)
- Telefone (opcional)
- CPF (opcional, para integração CRM)

### Campos Personalizados

Cada evento pode ter campos adicionais configuráveis via `event_form_fields`:

| Tipo | Descrição |
|------|-----------|
| text | Campo de texto livre |
| email | Email com validação |
| phone | Telefone com máscara |
| select | Lista de opções |
| checkbox | Caixa de seleção |

### Configuração de Campos

1. Acesse `/admin/crm/eventos`
2. Selecione o evento
3. Aba "Formulário"
4. Adicione/remova campos conforme necessário

## Integração com CRM

### Automática

Quando um usuário se inscreve em um evento:
1. Registro criado em `event_registrations`
2. Se CPF informado, lead criado/atualizado em `crm_leads`
3. Interação registrada em `crm_interactions`

Quando um negócio do pipeline é vinculado a um evento com **Inscrever automaticamente** ativo:
1. O sistema usa o lead vinculado ao negócio ou os dados do participante informados no próprio negócio.
2. A inscrição é criada ou reativada em `event_registrations` com status confirmado.
3. `events.current_participants` é sempre recalculado a partir das inscrições confirmadas/presentes, mantendo a relação correta entre inscritos e vagas disponíveis.

### Campos Rastreados

| Origem | Campo CRM |
|--------|-----------|
| Nome | full_name |
| Email | email |
| CPF | cpf |
| Telefone | phone |
| Evento | activity_name (em crm_interactions) |

## Status do Evento

| Status | Descrição |
|--------|-----------|
| draft | Rascunho, não visível ao público |
| published | Publicado, visível e aberto para inscrições |
| cancelled | Cancelado |
| completed | Concluído |

## Status de Inscrição

| Status | Descrição |
|--------|-----------|
| pending | Aguardando confirmação/pagamento |
| confirmed | Confirmado |
| cancelled | Cancelado |
| attended | Presente (após check-in) |

## Boas Práticas

1. **Slug**: se não for informado, o sistema gera automaticamente a partir do título
2. **Definir limite de vagas** - Controle de capacidade
3. **Usar imagens de qualidade** - Aspecto visual atrativo
4. **Descrição completa** - Todas as informações necessárias
5. **Publicar com antecedência** - Tempo para divulgação
6. **Campos opcionais vazios viram `null`**: ex. data/hora fim (`date_end`)
7. **Inscrição pelo pipeline exige participante válido**: para atualizar as vagas, informe lead vinculado ou nome/email no negócio.

## Navegação

Os eventos estão acessíveis via:
- Menu principal do portal
- Rodapé do site
- Links diretos (/eventos)
